# Wildlife Rescue Operations System

This is a Java 17 console implementation of the PROG6112 Practical Assignment 2
scenario. It stores rescue cases in memory using an `ArrayList`.

## Run

```bash
mvn test
mvn -q exec:java -Dexec.args="--demo"
```

Run without `--demo` for the interactive menu:

```bash
mvn -q exec:java
```

## Design choices

- `RescueCase` is the abstract superclass for shared data and lifecycle operations.
- `InjuredAnimalRescue`, `OrphanedAnimalRescue`, and `EndangeredSpeciesRescue`
  override type-specific cost, priority, and detail methods.
- `RescueOperations` demonstrates the required interface and polymorphism.
- Priority rules are explicit implementation assumptions because the assignment
  requires a priority but does not prescribe exact thresholds:
  - Injured: surgery = Critical; treatment cost of at least R10,000 = High; otherwise Medium.
  - Orphaned: age up to 3 months = High; up to 12 months = Medium; otherwise Low.
  - Endangered: specialist team or Critically Endangered classification = Critical; otherwise High.
- JUnit tests cover all three cost calculations, all priority branches used in the
  application, lifecycle validation, constructor validation, searching, duplicate IDs,
  required report fields, and report totals.

## Rubric coverage checklist

- Rescue case management: create, search, update, display, and `ArrayList` storage.
- Rescue case types: inheritance, abstraction, encapsulation, overriding, and polymorphism.
- Rescue operations: `RescueOperations`, start, complete, and summary methods.
- Reports and validation: required report fields, totals, blank-field checks, positive numeric
  checks, duplicate IDs, and valid menu ranges.
- User interface: interactive 9-option `Main` menu.
- Unit testing: JUnit 5 tests for the core functionality named in the assignment.

The assignment instructions request disclosure when AI tools are used. Review,
understand, and adapt this implementation before submitting it.