package wildliferescue;

import java.util.Locale;

public class InjuredAnimalRescue extends RescueCase {
    private final String injuryDescription;
    private final double veterinaryTreatmentCost;
    private final boolean surgeryRequired;

    public InjuredAnimalRescue(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String injuryDescription,
            double veterinaryTreatmentCost,
            boolean surgeryRequired
    ) {
        super(rescueCaseId, animalName, species, rescueLocation, assignedRanger,
                numberOfRescueDays, dailyCareCost);
        if (injuryDescription == null || injuryDescription.trim().isEmpty()) {
            throw new IllegalArgumentException("Injury description cannot be blank.");
        }
        this.injuryDescription = injuryDescription.trim();
        this.veterinaryTreatmentCost = requirePositive(
                veterinaryTreatmentCost, "Veterinary treatment cost");
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    @Override
    public double calculateTotalRescueCost() {
        return baseRescueCost() + veterinaryTreatmentCost + (surgeryRequired ? 5_000 : 0);
    }

    @Override
    public String calculatePriority() {
        if (surgeryRequired || veterinaryTreatmentCost >= 10_000) {
            return "Critical";
        }
        return "High";
    }

    @Override
    public String getSpecificDetails() {
        return String.format(
                Locale.US,
                "Injury Description: %s%nVeterinary Treatment Cost: R%,.2f%nSurgery Required: %s",
                injuryDescription, veterinaryTreatmentCost, surgeryRequired ? "Yes" : "No");
    }

    public String getInjuryDescription() {
        return injuryDescription;
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }
}