package wildliferescue;

import java.util.Locale;
import java.util.Scanner;

public class WildlifeRescueApp {
    private final RescueManager manager;
    private final Scanner scanner;

    public WildlifeRescueApp() {
        manager = new RescueManager();
        scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        WildlifeRescueApp app = new WildlifeRescueApp();
        if (args.length > 0 && "--demo".equalsIgnoreCase(args[0])) {
            app.runDemo();
        } else {
            app.runMenu();
        }
    }

    private void runMenu() {
        boolean running = true;
        while (running) {
            printMenu();
            int option = readInt("Select an option: ", 1, 6);
            try {
                switch (option) {
                    case 1 -> createRescueCase();
                    case 2 -> searchRescueCase();
                    case 3 -> updateRescueStatus();
                    case 4 -> displayAllRescueCases();
                    case 5 -> System.out.println(manager.generateReport());
                    case 6 -> running = false;
                    default -> throw new IllegalStateException("Unexpected menu option.");
                }
            } catch (IllegalArgumentException exception) {
                System.out.println("Input error: " + exception.getMessage());
            }
            if (running) {
                System.out.println("\nPress Enter to continue...");
                scanner.nextLine();
            }
        }
        System.out.println("Thank you for using the Wildlife Rescue Operations System.");
    }

    private void printMenu() {
        System.out.println("\n======================================");
        System.out.println("     WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("======================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
    }

    private void createRescueCase() {
        String id = readRequired("Rescue Case ID: ");
        if (manager.findById(id).isPresent()) {
            throw new IllegalArgumentException("Rescue Case ID must be unique.");
        }
        String animalName = readRequired("Animal Name: ");
        String species = readRequired("Species: ");
        String location = readRequired("Rescue Location: ");
        String ranger = readRequired("Assigned Ranger: ");
        int days = readInt("Number of Rescue Days: ", 1, Integer.MAX_VALUE);
        double dailyCost = readDouble("Daily Care Cost: ", 0.01);
        int type = readInt("Type (1=Injured, 2=Orphaned, 3=Endangered): ", 1, 3);

        RescueCase rescueCase;
        if (type == 1) {
            String injury = readRequired("Injury Description: ");
            double veterinaryCost = readDouble("Veterinary Treatment Cost: ", 0.01);
            boolean surgery = readYesNo("Surgery Required (y/n): ");
            rescueCase = new InjuredAnimalRescue(id, animalName, species, location, ranger,
                    days, dailyCost, injury, veterinaryCost, surgery);
        } else if (type == 2) {
            int age = readInt("Estimated Age (Months): ", 1, Integer.MAX_VALUE);
            double feedingCost = readDouble("Feeding Cost: ", 0.01);
            boolean foster = readYesNo("Foster Care Required (y/n): ");
            rescueCase = new OrphanedAnimalRescue(id, animalName, species, location, ranger,
                    days, dailyCost, age, feedingCost, foster);
        } else {
            String classification = readRequired("Conservation Classification: ");
            double securityCost = readDouble("Security Cost: ", 0.01);
            boolean specialist = readYesNo("Specialist Team Required (y/n): ");
            rescueCase = new EndangeredSpeciesRescue(id, animalName, species, location, ranger,
                    days, dailyCost, classification, securityCost, specialist);
        }

        manager.addRescueCase(rescueCase);
        System.out.println("Rescue case created successfully.");
    }

    private void searchRescueCase() {
        String id = readRequired("Enter Rescue Case ID: ");
        manager.findById(id).ifPresentOrElse(
                rescueCase -> System.out.println("\n" + rescueCase.generateSummary()
                        + "\n" + rescueCase.getSpecificDetails()),
                () -> System.out.println("No rescue case found with that ID."));
    }

    private void updateRescueStatus() {
        String id = readRequired("Enter Rescue Case ID: ");
        if (manager.findById(id).isEmpty()) {
            System.out.println("No rescue case found with that ID.");
            return;
        }
        int status = readInt("Status (1=Registered, 2=In Progress, 3=Completed): ", 1, 3);
        RescueStatus newStatus = RescueStatus.values()[status - 1];
        manager.updateStatus(id, newStatus);
        System.out.println("Rescue status updated to " + newStatus + ".");
    }

    private void displayAllRescueCases() {
        if (manager.getAllRescueCases().isEmpty()) {
            System.out.println("No rescue cases have been recorded.");
            return;
        }
        manager.getAllRescueCases().forEach(rescueCase ->
                System.out.println("\n" + rescueCase.generateSummary()));
    }

    private void runDemo() {
        RescueCase injured = new InjuredAnimalRescue(
                "WR101", "Kaya", "African Elephant", "Kruger National Park", "Ranger Thabo",
                5, 1_500, "Leg injury", 8_000, true);
        RescueCase orphaned = new OrphanedAnimalRescue(
                "WR102", "Zuri", "White Rhino", "Hluhluwe", "Ranger Naledi",
                4, 1_000, 4, 3_500, true);
        RescueCase endangered = new EndangeredSpeciesRescue(
                "WR103", "Mpho", "Black Rhino", "Limpopo", "Ranger Kabelo",
                7, 1_200, "Critically Endangered", 12_000, true);

        manager.addRescueCase(injured);
        manager.addRescueCase(orphaned);
        manager.addRescueCase(endangered);

        injured.startRescue();
        orphaned.startRescue();
        endangered.startRescue();
        orphaned.completeRescue();

        System.out.println("DEMO: Search for WR102");
        System.out.println(manager.findById("WR102").orElseThrow().generateSummary());
        System.out.println("\n" + manager.generateReport());
    }

    private String readRequired(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) {
                return value;
            }
            System.out.println("This value cannot be blank. Please try again.");
        }
    }

    private int readInt(String prompt, int minimum, int maximum) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value >= minimum && value <= maximum) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // The message below keeps the menu running after invalid input.
            }
            System.out.printf(Locale.US, "Enter a whole number from %d to %d.%n", minimum, maximum);
        }
    }

    private double readDouble(String prompt, double minimum) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                double value = Double.parseDouble(input);
                if (Double.isFinite(value) && value >= minimum) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // The message below keeps the menu running after invalid input.
            }
            System.out.printf(Locale.US, "Enter a number greater than or equal to %.2f.%n", minimum);
        }
    }

    private boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim().toLowerCase(Locale.ROOT);
            if (input.equals("y") || input.equals("yes")) {
                return true;
            }
            if (input.equals("n") || input.equals("no")) {
                return false;
            }
            System.out.println("Please enter y/yes or n/no.");
        }
    }
}