package wildliferescue;

import java.util.Locale;

public class EndangeredSpeciesRescue extends RescueCase {
    private final String conservationClassification;
    private final double securityCost;
    private final boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String conservationClassification,
            double securityCost,
            boolean specialistTeamRequired
    ) {
        super(rescueCaseId, animalName, species, rescueLocation, assignedRanger,
                numberOfRescueDays, dailyCareCost);
        if (conservationClassification == null || conservationClassification.trim().isEmpty()) {
            throw new IllegalArgumentException("Conservation classification cannot be blank.");
        }
        this.conservationClassification = conservationClassification.trim();
        this.securityCost = requirePositive(securityCost, "Security cost");
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    public double calculateTotalRescueCost() {
        return baseRescueCost() + securityCost + (specialistTeamRequired ? 8_000 : 0);
    }

    @Override
    public String calculatePriority() {
        String classification = conservationClassification.toLowerCase(Locale.ROOT);
        if (specialistTeamRequired || classification.contains("critically endangered")) {
            return "Critical";
        }
        return "High";
    }

    @Override
    public String getSpecificDetails() {
        return String.format(
                Locale.US,
                "Conservation Classification: %s%nSecurity Cost: R%,.2f%nSpecialist Team Required: %s",
                conservationClassification, securityCost, specialistTeamRequired ? "Yes" : "No");
    }

    public String getConservationClassification() {
        return conservationClassification;
    }

    public double getSecurityCost() {
        return securityCost;
    }

    public boolean isSpecialistTeamRequired() {
        return specialistTeamRequired;
    }
}