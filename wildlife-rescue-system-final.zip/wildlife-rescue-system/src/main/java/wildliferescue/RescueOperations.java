package wildliferescue;

/**
 * Operations that every rescue case must support.
 */
public interface RescueOperations {
    void startRescue();

    void completeRescue();

    String generateSummary();
}