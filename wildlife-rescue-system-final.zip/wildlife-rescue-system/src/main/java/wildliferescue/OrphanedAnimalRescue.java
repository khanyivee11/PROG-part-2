package wildliferescue;

import java.util.Locale;

public class OrphanedAnimalRescue extends RescueCase {
    private final int estimatedAgeMonths;
    private final double feedingCost;
    private final boolean fosterCareRequired;

    public OrphanedAnimalRescue(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            int estimatedAgeMonths,
            double feedingCost,
            boolean fosterCareRequired
    ) {
        super(rescueCaseId, animalName, species, rescueLocation, assignedRanger,
                numberOfRescueDays, dailyCareCost);
        this.estimatedAgeMonths = requirePositive(estimatedAgeMonths, "Estimated age");
        this.feedingCost = requirePositive(feedingCost, "Feeding cost");
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    @Override
    public double calculateTotalRescueCost() {
        return baseRescueCost() + feedingCost + (fosterCareRequired ? 2_500 : 0);
    }

    @Override
    public String calculatePriority() {
        if (estimatedAgeMonths <= 3) {
            return "High";
        }
        if (estimatedAgeMonths <= 12) {
            return "Medium";
        }
        return "Low";
    }

    @Override
    public String getSpecificDetails() {
        return String.format(
                Locale.US,
                "Estimated Age (Months): %d%nFeeding Cost: R%,.2f%nFoster Care Required: %s",
                estimatedAgeMonths, feedingCost, fosterCareRequired ? "Yes" : "No");
    }

    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }
}