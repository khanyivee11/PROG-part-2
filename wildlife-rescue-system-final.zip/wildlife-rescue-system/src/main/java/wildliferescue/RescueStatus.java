package wildliferescue;

public enum RescueStatus {
    REGISTERED("Registered"),
    IN_PROGRESS("Rescue in Progress"),
    COMPLETED("Completed");

    private final String displayName;

    RescueStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}