package wildliferescue;

import java.util.Locale;

/**
 * Abstract base class containing information shared by every rescue case.
 */
public abstract class RescueCase implements RescueOperations {
    private final String rescueCaseId;
    private final String animalName;
    private final String species;
    private final String rescueLocation;
    private final String assignedRanger;
    private final int numberOfRescueDays;
    private final double dailyCareCost;
    private RescueStatus currentStatus;

    protected RescueCase(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost
    ) {
        this.rescueCaseId = requireText(rescueCaseId, "Rescue Case ID");
        this.animalName = requireText(animalName, "Animal Name");
        this.species = requireText(species, "Species");
        this.rescueLocation = requireText(rescueLocation, "Rescue Location");
        this.assignedRanger = requireText(assignedRanger, "Assigned Ranger");

        this.numberOfRescueDays = requirePositive(numberOfRescueDays, "Number of rescue days");
        this.dailyCareCost = requirePositive(dailyCareCost, "Daily care cost");
        this.currentStatus = RescueStatus.REGISTERED;
    }

    private static String requireText(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank.");
        }
        return value.trim();
    }

    protected static double requirePositive(double value, String fieldName) {
        if (!Double.isFinite(value) || value <= 0) {
            throw new IllegalArgumentException(fieldName + " must be greater than zero.");
        }
        return value;
    }

    protected static int requirePositive(int value, String fieldName) {
        if (value <= 0) {
            throw new IllegalArgumentException(fieldName + " must be greater than zero.");
        }
        return value;
    }

    protected final double baseRescueCost() {
        return numberOfRescueDays * dailyCareCost;
    }

    public abstract String getRescueType();

    public abstract double calculateTotalRescueCost();

    public abstract String calculatePriority();

    public abstract String getSpecificDetails();

    @Override
    public void startRescue() {
        if (currentStatus != RescueStatus.REGISTERED) {
            throw new IllegalStateException(
                    "Only a registered rescue can be started (current status: " + currentStatus + ").");
        }
        currentStatus = RescueStatus.IN_PROGRESS;
    }

    @Override
    public void completeRescue() {
        if (currentStatus != RescueStatus.IN_PROGRESS) {
            throw new IllegalStateException(
                    "Only an in-progress rescue can be completed (current status: " + currentStatus + ").");
        }
        currentStatus = RescueStatus.COMPLETED;
    }

    @Override
    public String generateSummary() {
        return String.format(
                Locale.US,
                "Case ID: %s%nRescue Type: %s%nSpecies: %s%nAssigned Ranger: %s%n"
                        + "Rescue Priority: %s%nCurrent Status: %s%nTotal Rescue Cost: R%,.2f",
                rescueCaseId,
                getRescueType(),
                species,
                assignedRanger,
                calculatePriority(),
                currentStatus,
                calculateTotalRescueCost()
        );
    }

    public String getRescueCaseId() {
        return rescueCaseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getNumberOfRescueDays() {
        return numberOfRescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public RescueStatus getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(RescueStatus currentStatus) {
        if (currentStatus == null) {
            throw new IllegalArgumentException("Rescue status cannot be null.");
        }
        this.currentStatus = currentStatus;
    }
}