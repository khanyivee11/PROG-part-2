package wildliferescue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Service layer for the required in-memory ArrayList of rescue cases.
 */
public class RescueManager {
    private final ArrayList<RescueCase> rescueCases = new ArrayList<>();

    public void addRescueCase(RescueCase rescueCase) {
        if (rescueCase == null) {
            throw new IllegalArgumentException("Rescue case cannot be null.");
        }
        if (findById(rescueCase.getRescueCaseId()).isPresent()) {
            throw new IllegalArgumentException(
                    "A rescue case with ID " + rescueCase.getRescueCaseId() + " already exists.");
        }
        rescueCases.add(rescueCase);
    }

    public Optional<RescueCase> findById(String rescueCaseId) {
        if (rescueCaseId == null || rescueCaseId.trim().isEmpty()) {
            return Optional.empty();
        }
        return rescueCases.stream()
                .filter(caseItem -> caseItem.getRescueCaseId().equalsIgnoreCase(rescueCaseId.trim()))
                .findFirst();
    }

    public void updateStatus(String rescueCaseId, RescueStatus newStatus) {
        RescueCase rescueCase = findById(rescueCaseId)
                .orElseThrow(() -> new IllegalArgumentException("Rescue case not found."));
        rescueCase.setCurrentStatus(newStatus);
    }

    public List<RescueCase> getAllRescueCases() {
        return Collections.unmodifiableList(rescueCases);
    }

    public String generateReport() {
        StringBuilder report = new StringBuilder();
        report.append("============================================================\n");
        report.append("                 WILDLIFE RESCUE REPORT\n");
        report.append("============================================================\n");

        double totalCost = 0;
        for (RescueCase rescueCase : rescueCases) {
            report.append(String.format(
                    Locale.US,
                    "Case ID        : %s%n"
                            + "Animal Name    : %s%n"
                            + "Type           : %s%n"
                            + "Species        : %s%n"
                            + "Location       : %s%n"
                            + "Assigned Ranger: %s%n"
                            + "Priority       : %s%n"
                            + "Status         : %s%n"
                            + "Total Cost     : R%,.2f%n"
                            + "Specific Info  : %s%n"
                            + "------------------------------------------------------------%n",
                    rescueCase.getRescueCaseId(),
                    rescueCase.getAnimalName(),
                    rescueCase.getRescueType(),
                    rescueCase.getSpecies(),
                    rescueCase.getRescueLocation(),
                    rescueCase.getAssignedRanger(),
                    rescueCase.calculatePriority(),
                    rescueCase.getCurrentStatus(),
                    rescueCase.calculateTotalRescueCost(),
                    rescueCase.getSpecificDetails()));
            totalCost += rescueCase.calculateTotalRescueCost();
        }

        report.append(String.format(
                Locale.US,
                "Total Rescue Cases: %d%nTotal Estimated Rescue Cost: R%,.2f%n",
                rescueCases.size(), totalCost));
        return report.toString();
    }
}