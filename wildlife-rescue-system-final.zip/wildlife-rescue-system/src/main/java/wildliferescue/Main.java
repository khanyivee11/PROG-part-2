package wildliferescue;

import java.util.Locale;
import java.util.Scanner;

/**
 * Console entry point for the Wildlife SA Rescue Operations System.
 *
 * The menu structure is based on the supplied Main-class snippets, adapted to
 * the project's existing RescueManager and rescue-case APIs.
 */
public class Main {
    private static final Scanner in = new Scanner(System.in);
    private static final RescueManager manager = new RescueManager();

    public static void main(String[] args) {
        runMenu();
    }

    private static void runMenu() {
        boolean running = true;
        while (running) {
            printMenu();
            switch (readInt("Enter choice: ", 1, 9)) {
                case 1 -> createCase();
                case 2 -> searchCase();
                case 3 -> updateStatus();
                case 4 -> displayAll();
                case 5 -> operate("start");
                case 6 -> operate("complete");
                case 7 -> operate("summary");
                case 8 -> System.out.println(manager.generateReport());
                case 9 -> {
                    running = false;
                    System.out.println("Goodbye.");
                }
                default -> throw new IllegalStateException("Unexpected menu option.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n===== WildLife SA Rescue Operations =====");
        System.out.println("1. Create new rescue case");
        System.out.println("2. Search rescue case by ID");
        System.out.println("3. Update rescue status");
        System.out.println("4. Display all rescue cases");
        System.out.println("5. Start rescue operation");
        System.out.println("6. Complete rescue operation");
        System.out.println("7. Generate rescue summary");
        System.out.println("8. Generate rescue report");
        System.out.println("9. Exit");
    }

    private static void createCase() {
        System.out.println("\nRescue type: 1. Injured  2. Orphaned  3. Endangered Species");
        int type = readInt("Select type: ", 1, 3);

        String id;
        while (true) {
            id = readText("Rescue Case ID: ");
            if (manager.findById(id).isPresent()) {
                System.out.println("Error: that Rescue Case ID already exists.");
            } else {
                break;
            }
        }

        String name = readText("Animal Name: ");
        String species = readText("Species: ");
        String location = readText("Rescue Location: ");
        String ranger = readText("Assigned Ranger: ");
        int days = readInt("Number of Rescue Days: ", 1, Integer.MAX_VALUE);
        double daily = readPositiveDouble("Daily Care Cost (R): ");

        RescueCase rescueCase;
        switch (type) {
            case 1 -> rescueCase = new InjuredAnimalRescue(
                    id, name, species, location, ranger, days, daily,
                    readText("Injury Description: "),
                    readPositiveDouble("Veterinary Treatment Cost (R): "),
                    readYesNo("Surgery required?"));
            case 2 -> rescueCase = new OrphanedAnimalRescue(
                    id, name, species, location, ranger, days, daily,
                    readInt("Estimated Age (months): ", 1, Integer.MAX_VALUE),
                    readPositiveDouble("Feeding Cost (R): "),
                    readYesNo("Foster care required?"));
            case 3 -> rescueCase = new EndangeredSpeciesRescue(
                    id, name, species, location, ranger, days, daily,
                    readText("Conservation Classification: "),
                    readPositiveDouble("Security Cost (R): "),
                    readYesNo("Specialist team required?"));
            default -> throw new IllegalStateException("Unexpected rescue type.");
        }

        manager.addRescueCase(rescueCase);
        System.out.println("Rescue case created successfully.");
    }

    private static void searchCase() {
        RescueCase rescueCase = manager.findById(readText("Rescue Case ID to search: "))
                .orElse(null);
        if (rescueCase == null) {
            System.out.println("No rescue case found with that ID.");
            return;
        }
        System.out.println(rescueCase.generateSummary());
        System.out.println(rescueCase.getSpecificDetails());
    }

    private static void updateStatus() {
        String id = readText("Rescue Case ID: ");
        RescueCase rescueCase = manager.findById(id).orElse(null);
        if (rescueCase == null) {
            System.out.println("No rescue case found with that ID.");
            return;
        }

        System.out.println("Current status: " + rescueCase.getCurrentStatus());
        System.out.println("1. Registered  2. Rescue in Progress  3. Completed");
        int choice = readInt("New status: ", 1, 3);
        manager.updateStatus(id, RescueStatus.values()[choice - 1]);
        System.out.println("Status updated to: " + rescueCase.getCurrentStatus());
    }

    private static void displayAll() {
        if (manager.getAllRescueCases().isEmpty()) {
            System.out.println("No rescue cases recorded.");
            return;
        }
        for (RescueCase rescueCase : manager.getAllRescueCases()) {
            System.out.println(rescueCase.generateSummary());
            System.out.println(rescueCase.getSpecificDetails());
            System.out.println();
        }
    }

    private static void operate(String action) {
        RescueCase rescueCase = manager.findById(readText("Rescue Case ID: "))
                .orElse(null);
        if (rescueCase == null) {
            System.out.println("No rescue case found with that ID.");
            return;
        }

        try {
            switch (action) {
                case "start" -> {
                    rescueCase.startRescue();
                    System.out.println("Rescue started. Status: " + rescueCase.getCurrentStatus());
                }
                case "complete" -> {
                    rescueCase.completeRescue();
                    System.out.println("Rescue completed. Status: " + rescueCase.getCurrentStatus());
                }
                case "summary" -> System.out.println(rescueCase.generateSummary());
                default -> throw new IllegalArgumentException("Unknown operation.");
            }
        } catch (IllegalStateException exception) {
            System.out.println("Error: " + exception.getMessage());
        }
    }

    private static String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = in.nextLine().trim();
            if (!value.isEmpty()) {
                return value;
            }
            System.out.println("Error: this field cannot be blank.");
        }
    }

    private static int readInt(String prompt, int minimum, int maximum) {
        while (true) {
            System.out.print(prompt);
            try {
                int value = Integer.parseInt(in.nextLine().trim());
                if (value >= minimum && value <= maximum) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // Continue prompting until valid input is supplied.
            }
            System.out.println(maximum == Integer.MAX_VALUE
                    ? "Error: enter a whole number of at least " + minimum + "."
                    : "Error: enter a number between " + minimum + " and " + maximum + ".");
        }
    }

    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double value = Double.parseDouble(in.nextLine().trim());
                if (value > 0 && Double.isFinite(value)) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // Continue prompting until valid input is supplied.
            }
            System.out.println("Error: enter a finite number greater than zero.");
        }
    }

    private static boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt + " (Y/N): ");
            String value = in.nextLine().trim().toLowerCase(Locale.ROOT);
            if (value.equals("y") || value.equals("yes")) {
                return true;
            }
            if (value.equals("n") || value.equals("no")) {
                return false;
            }
            System.out.println("Error: enter Y or N.");
        }
    }
}