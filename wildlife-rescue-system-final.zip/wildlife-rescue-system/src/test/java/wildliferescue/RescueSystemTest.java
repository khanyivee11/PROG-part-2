package wildliferescue;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RescueSystemTest {
    @Test
    void injuredRescueIncludesTreatmentAndSurgeryCosts() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR001", "Kaya", "Elephant", "Kruger", "Thabo",
                2, 1_000, "Broken leg", 5_000, true);

        assertEquals(12_000, rescue.calculateTotalRescueCost(), 0.001);
    }

    @Test
    void eachRescueTypeCalculatesAnAppropriatePriority() {
        InjuredAnimalRescue injured = new InjuredAnimalRescue(
                "WR001", "Kaya", "Elephant", "Kruger", "Thabo",
                2, 1_000, "Broken leg", 5_000, true);
        OrphanedAnimalRescue orphaned = new OrphanedAnimalRescue(
                "WR002", "Zuri", "Rhino", "Hluhluwe", "Naledi",
                2, 500, 3, 1_000, false);
        EndangeredSpeciesRescue endangered = new EndangeredSpeciesRescue(
                "WR003", "Mpho", "Pangolin", "Limpopo", "Kabelo",
                2, 500, "Critically Endangered", 1_000, false);

        assertEquals("Critical", injured.calculatePriority());
        assertEquals("High", orphaned.calculatePriority());
        assertEquals("Critical", endangered.calculatePriority());
    }

    @Test
    void orphanedAndEndangeredRescueCostsIncludeTheirAdditionalFees() {
        OrphanedAnimalRescue orphaned = new OrphanedAnimalRescue(
                "WR004", "Nala", "Lion", "Pretoria", "Mpho",
                3, 500, 2, 1_200, true);
        EndangeredSpeciesRescue endangered = new EndangeredSpeciesRescue(
                "WR005", "Tala", "Pangolin", "Limpopo", "Kabelo",
                4, 750, "Endangered", 2_000, true);

        assertEquals(5_200, orphaned.calculateTotalRescueCost(), 0.001);
        assertEquals(13_000, endangered.calculateTotalRescueCost(), 0.001);
    }

    @Test
    void lifecycleRejectsInvalidStatusTransitions() {
        RescueCase rescue = new OrphanedAnimalRescue(
                "WR006", "Zuri", "Rhino", "Hluhluwe", "Naledi",
                2, 500, 3, 1_000, false);

        assertThrows(IllegalStateException.class, rescue::completeRescue);
        rescue.startRescue();
        assertThrows(IllegalStateException.class, rescue::startRescue);
        rescue.completeRescue();
        assertThrows(IllegalStateException.class, rescue::completeRescue);
    }

    @Test
    void constructorsRejectBlankAndNonFiniteValues() {
        assertThrows(IllegalArgumentException.class, () -> new InjuredAnimalRescue(
                "WR007", "Kaya", "Elephant", "Kruger", "Thabo",
                2, Double.NaN, "Broken leg", 5_000, false));
        assertThrows(IllegalArgumentException.class, () -> new InjuredAnimalRescue(
                "WR008", "Kaya", "Elephant", "Kruger", "Thabo",
                2, 1_000, " ", 5_000, false));
    }

    @Test
    void rescueOperationsUpdateStatus() {
        RescueCase rescue = new OrphanedAnimalRescue(
                "WR001", "Zuri", "Rhino", "Hluhluwe", "Naledi",
                2, 500, 3, 1_000, false);

        rescue.startRescue();
        assertEquals(RescueStatus.IN_PROGRESS, rescue.getCurrentStatus());
        rescue.completeRescue();
        assertEquals(RescueStatus.COMPLETED, rescue.getCurrentStatus());
    }

    @Test
    void managerFindsAnExistingRescueCase() {
        RescueManager manager = new RescueManager();
        RescueCase rescue = new InjuredAnimalRescue(
                "WR001", "Kaya", "Elephant", "Kruger", "Thabo",
                2, 1_000, "Broken leg", 5_000, false);
        manager.addRescueCase(rescue);

        assertTrue(manager.findById("wr001").isPresent());
        assertEquals("Kaya", manager.findById("WR001").orElseThrow().getAnimalName());
    }

    @Test
    void managerPreventsDuplicateCaseIds() {
        RescueManager manager = new RescueManager();
        manager.addRescueCase(new InjuredAnimalRescue(
                "WR001", "Kaya", "Elephant", "Kruger", "Thabo",
                2, 1_000, "Broken leg", 5_000, false));

        assertThrows(IllegalArgumentException.class, () -> manager.addRescueCase(
                new OrphanedAnimalRescue(
                        "wr001", "Zuri", "Rhino", "Hluhluwe", "Naledi",
                        2, 500, 3, 1_000, false)));
    }

    @Test
    void reportContainsRequiredFieldsAndTotals() {
        RescueManager manager = new RescueManager();
        manager.addRescueCase(new EndangeredSpeciesRescue(
                "WR003", "Mpho", "Pangolin", "Limpopo", "Kabelo",
                2, 500, "Endangered", 1_000, true));

        String report = manager.generateReport();
        assertTrue(report.contains("WR003"));
        assertTrue(report.contains("Endangered Species Rescue"));
        assertTrue(report.contains("Limpopo"));
        assertTrue(report.contains("Kabelo"));
        assertTrue(report.contains("Critical"));
        assertTrue(report.contains("Registered"));
        assertTrue(report.contains("Total Rescue Cases: 1"));
        assertTrue(report.contains("Total Estimated Rescue Cost: R10,000.00"));
    }
}